=== Website to APK Converter ===
Contributors: jsrtechnos
Tags: apk, android, webview, website to app, wordpress
Requires at least: 5.5
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Visitors website URL daal ke ek ready Android Studio project (.zip) generate kar sakte hain, jo GitHub Actions se auto-build hoke APK banata hai.

== Description ==

Ye plugin ek shortcode deta hai: `[website_to_apk_form]`

Kisi bhi page ya post mein ye shortcode daal do — ek form dikhega jahan visitor:

1. Website URL
2. App Name (optional)
3. Package Name (optional)

daal ke submit karta hai. Plugin turant ek ready **Android Studio project (.zip)** generate karke
download kara deta hai, jisme WebView pehle se uss URL par set hota hai.

Zip ke andar ek **GitHub Actions workflow** included hai — GitHub par push karte hi 2-3 minute mein:

* `app-debug-apk` — testing APK, hamesha milta hai
* `app-release-signed-apk` — Play Store-ready signed APK, sirf tab jab keystore secrets GitHub repo mein add kiye gaye hon (dekhein zip ke andar README.md aur `generate-keystore.sh`)

= Requirements =

* PHP 7.4 ya usse zyada
* PHP `zip` extension enabled (zyadatar hosting par by default hota hai)

== Installation ==

1. Plugin ko WordPress admin se upload karen: **Plugins > Add New > Upload Plugin**
2. Activate karen
3. Kisi bhi page/post mein ye shortcode daalen: `[website_to_apk_form]`
4. Page publish/view karen — form dikhega

== Frequently Asked Questions ==

= Kya ye asli signed APK deta hai? =

Debug APK turant milti hai (testing ke liye). Signed release APK ke liye ek baar keystore
generate karke GitHub repository secrets mein daalna hota hai — uske baad har push par
automatically signed APK bhi ban jaati hai. Poori steps zip ke andar README.md mein hain.

= Kya server par khud APK compile hoti hai? =

Nahi — APK compilation GitHub Actions (free) par hoti hai, aapke apne hosting server par nahi.
Isse hosting par Android SDK/Gradle install karne ki zaroorat nahi padti.

== Changelog ==

= 1.0.0 =
* Initial release: shortcode form, Android WebView project generator, GitHub Actions auto-build (debug + signed release).
