<?php
/**
 * Plugin Name: Website to APK Converter
 * Plugin URI: https://jsraiwebstudio.com
 * Description: Visitors website URL daal ke ek ready Android Studio project (.zip) generate kar sakte hain, jo GitHub Actions se auto-build hoke APK banata hai. Use karne ke liye kisi bhi page/post mein [website_to_apk_form] shortcode daal dein.
 * Version: 1.0.0
 * Author: JSR Technos
 * Author URI: https://jsraiwebstudio.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: website-to-apk-converter
 */

if (!defined('ABSPATH')) exit;

define('W2A_VERSION', '1.0.0');
define('W2A_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('W2A_PLUGIN_URL', plugin_dir_url(__FILE__));
define('W2A_PLUGIN_FILE', __FILE__);

require_once W2A_PLUGIN_DIR . 'includes/class-w2a-generator.php';
require_once W2A_PLUGIN_DIR . 'includes/class-w2a-shortcode.php';

register_activation_hook(__FILE__, ['W2A_Plugin', 'on_activation']);

final class W2A_Plugin {

    public static function on_activation() {
        if (!class_exists('ZipArchive')) {
            deactivate_plugins(plugin_basename(W2A_PLUGIN_FILE));
            wp_die(
                'Website to APK Converter activate nahi ho saka: PHP "zip" extension server par enabled nahi hai. ' .
                'Apne hosting provider se ye extension enable karwayen, phir dobara activate karen.'
            );
        }
    }

    public static function admin_notice_shortcode_hint() {
        $screen = get_current_screen();
        if ($screen && $screen->id === 'plugins') {
            echo '<div class="notice notice-info is-dismissible"><p>';
            echo '<strong>Website to APK Converter:</strong> is shortcode ko kisi bhi page ya post mein daal dein: ';
            echo '<code>[website_to_apk_form]</code>';
            echo '</p></div>';
        }
    }
}

add_action('plugins_loaded', function () {
    W2A_Shortcode::init();
});

add_action('admin_notices', ['W2A_Plugin', 'admin_notice_shortcode_hint']);
