<?php
// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// This plugin does not create any database tables or persistent options,
// so there is nothing else to clean up.
