<?php
if (!defined('ABSPATH')) exit;

class W2A_Generator {

    public static function sanitize_app_name($name) {
        $name = trim($name);
        $name = preg_replace('/[^\p{L}\p{N}\s\-\_]/u', '', $name);
        if ($name === '') return 'My WebApp';
        return function_exists('mb_substr') ? mb_substr($name, 0, 40) : substr($name, 0, 40);
    }

    public static function sanitize_package_name($url, $custom = '') {
        if (!empty($custom) && preg_match('/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/', $custom)) {
            return $custom;
        }
        $host = parse_url($url, PHP_URL_HOST);
        $host = preg_replace('/^www\./', '', $host);
        $parts = array_reverse(explode('.', $host));
        $parts = array_map(function ($p) {
            $p = preg_replace('/[^a-zA-Z0-9]/', '', $p);
            if ($p === '' || is_numeric($p[0])) $p = 'a' . $p;
            return strtolower($p);
        }, $parts);
        $parts[] = 'app';
        return implode('.', array_filter($parts));
    }

    private static function recursive_copy($src, $dst) {
        $dir = opendir($src);
        if (!file_exists($dst)) {
            wp_mkdir_p($dst);
        }
        while (($file = readdir($dir)) !== false) {
            if ($file === '.' || $file === '..') continue;
            $srcPath = $src . '/' . $file;
            $dstPath = $dst . '/' . $file;
            if (is_dir($srcPath)) {
                self::recursive_copy($srcPath, $dstPath);
            } else {
                copy($srcPath, $dstPath);
            }
        }
        closedir($dir);
    }

    private static function replace_placeholders_in_file($path, $replacements) {
        $ext = pathinfo($path, PATHINFO_EXTENSION);
        $textExts = ['java', 'xml', 'gradle', 'properties', 'yml', 'yaml', 'pro'];
        if (!in_array($ext, $textExts, true)) return;
        $content = file_get_contents($path);
        $content = strtr($content, $replacements);
        file_put_contents($path, $content);
    }

    private static function walk_and_replace($dir, $replacements) {
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . '/' . $item;
            if (is_dir($path)) {
                self::walk_and_replace($path, $replacements);
            } else {
                self::replace_placeholders_in_file($path, $replacements);
            }
        }
    }

    private static function zip_directory($sourceDir, $zipFile) {
        $zip = new ZipArchive();
        if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            return false;
        }
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($sourceDir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($sourceDir) + 1);
                $zip->addFile($filePath, $relativePath);

                // keep executable bit for scripts so ./gradlew works after unzip
                $basename = basename($relativePath);
                if ($basename === 'gradlew' || substr($basename, -3) === '.sh') {
                    $zip->setExternalAttributesName($relativePath, ZipArchive::OPSYS_UNIX, 0100755 << 16);
                }
            }
        }
        $zip->close();
        return true;
    }

    private static function rrmdir($dir) {
        if (!is_dir($dir)) return;
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . '/' . $item;
            is_dir($path) ? self::rrmdir($path) : unlink($path);
        }
        rmdir($dir);
    }

    /**
     * Generates the customized Android project zip and streams it to the browser.
     * Returns a WP_Error on failure instead of streaming.
     */
    public static function generate_and_stream($websiteUrl, $appName, $customPackage) {
        if (!class_exists('ZipArchive')) {
            return new WP_Error('w2a_no_zip', 'Server par PHP "zip" extension enabled nahi hai.');
        }

        if (!filter_var($websiteUrl, FILTER_VALIDATE_URL) || !preg_match('/^https?:\/\//i', $websiteUrl)) {
            return new WP_Error('w2a_bad_url', 'Sahi website URL dalen (http:// ya https:// ke saath).');
        }

        $appName = self::sanitize_app_name($appName);
        $packageName = self::sanitize_package_name($websiteUrl, $customPackage);
        $packagePath = str_replace('.', '/', $packageName);

        $templateDir = W2A_PLUGIN_DIR . 'template';
        if (!is_dir($templateDir)) {
            return new WP_Error('w2a_no_template', 'Plugin template folder missing hai.');
        }

        $tmpRoot = trailingslashit(get_temp_dir()) . 'w2a_' . wp_generate_password(12, false);
        self::recursive_copy($templateDir, $tmpRoot);

        // move MainActivity.java into the correct package path
        $oldJavaDir = $tmpRoot . '/app/src/main/java/com/webapp2apk/template';
        $newJavaDir = $tmpRoot . '/app/src/main/java/' . $packagePath;

        if ($oldJavaDir !== $newJavaDir) {
            wp_mkdir_p($newJavaDir);
            rename($oldJavaDir . '/MainActivity.java', $newJavaDir . '/MainActivity.java');

            // clean up now-empty old package dirs, walking upward,
            // never touching anything that overlaps the new package path
            $javaRoot = $tmpRoot . '/app/src/main/java';
            $dir = $oldJavaDir;
            while ($dir !== $javaRoot && strlen($dir) > strlen($javaRoot)) {
                if (strpos($newJavaDir . '/', rtrim($dir, '/') . '/') === 0) {
                    break;
                }
                $contents = @scandir($dir);
                if ($contents === false || count(array_diff($contents, ['.', '..'])) > 0) {
                    break;
                }
                rmdir($dir);
                $dir = dirname($dir);
            }
        }

        $replacements = [
            '{{URL}}'          => $websiteUrl,
            '{{APP_NAME}}'     => $appName,
            '{{PACKAGE_NAME}}' => $packageName,
        ];
        self::walk_and_replace($tmpRoot, $replacements);

        $zipName = preg_replace('/[^a-zA-Z0-9\-]/', '_', $appName) . '_android_project.zip';
        $zipPath = trailingslashit(get_temp_dir()) . 'w2a_' . wp_generate_password(12, false) . '.zip';

        if (!self::zip_directory($tmpRoot, $zipPath)) {
            self::rrmdir($tmpRoot);
            return new WP_Error('w2a_zip_failed', 'Zip banane mein fail hua.');
        }

        self::rrmdir($tmpRoot);

        if (!headers_sent()) {
            nocache_headers();
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $zipName . '"');
            header('Content-Length: ' . filesize($zipPath));
        }
        readfile($zipPath);
        unlink($zipPath);
        exit;
    }
}
