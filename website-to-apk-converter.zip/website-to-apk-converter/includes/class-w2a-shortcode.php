<?php
if (!defined('ABSPATH')) exit;

class W2A_Shortcode {

    public static function init() {
        add_shortcode('website_to_apk_form', [__CLASS__, 'render_form']);
        add_action('admin_post_w2a_generate', [__CLASS__, 'handle_submission']);
        add_action('admin_post_nopriv_w2a_generate', [__CLASS__, 'handle_submission']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'maybe_enqueue_assets']);
    }

    public static function maybe_enqueue_assets() {
        if (is_a(get_post(), 'WP_Post') && has_shortcode(get_post()->post_content, 'website_to_apk_form')) {
            wp_enqueue_style(
                'w2a-style',
                W2A_PLUGIN_URL . 'assets/css/w2a-style.css',
                [],
                W2A_VERSION
            );
        }
    }

    public static function render_form($atts = []) {
        // enqueue here too, in case the shortcode runs outside the main post content
        // (widgets, page builders, etc.)
        wp_enqueue_style('w2a-style', W2A_PLUGIN_URL . 'assets/css/w2a-style.css', [], W2A_VERSION);

        $nonce = wp_create_nonce('w2a_generate_action');
        $action_url = esc_url(admin_url('admin-post.php'));

        $error = '';
        if (isset($_GET['w2a_error'])) {
            $error = sanitize_text_field(wp_unslash($_GET['w2a_error']));
        }

        ob_start();
        ?>
        <div class="w2a-card">
            <h2 class="w2a-title">🌐 Website → APK Converter</h2>
            <p class="w2a-subtitle">
                Apni website ka link dalen, Android Studio project (.zip) download karen,
                aur GitHub par push karte hi APK khud-ba-khud ban jayegi.
            </p>

            <?php if ($error) : ?>
                <div class="w2a-error"><?php echo esc_html($error); ?></div>
            <?php endif; ?>

            <form method="POST" action="<?php echo $action_url; ?>">
                <input type="hidden" name="action" value="w2a_generate">
                <?php wp_nonce_field('w2a_generate_action', 'w2a_nonce'); ?>

                <label class="w2a-label" for="w2a_website_url">Website URL *</label>
                <input class="w2a-input" type="url" id="w2a_website_url" name="website_url"
                       placeholder="https://example.com" required>

                <label class="w2a-label" for="w2a_app_name">App Name</label>
                <input class="w2a-input" type="text" id="w2a_app_name" name="app_name"
                       placeholder="My WebApp" maxlength="40">

                <label class="w2a-label" for="w2a_package_name">Package Name (optional)</label>
                <input class="w2a-input" type="text" id="w2a_package_name" name="package_name"
                       placeholder="com.example.app">
                <div class="w2a-hint">Khaali chhod dein to website ke domain se auto-generate ho jayega</div>

                <button class="w2a-button" type="submit">Android Project Generate Karen</button>
            </form>

            <div class="w2a-steps">
                <b>Uske baad APK kaise banayen:</b><br>
                1. Zip file download karke extract karen<br>
                2. Ek naya GitHub repository banayen aur ye files push karen<br>
                3. Repo ke "Actions" tab mein 2-3 minute mein APK build ho jayega<br>
                4. "app-debug-apk" artifact download karen — yehi aapki APK hai
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function handle_submission() {
        if (
            !isset($_POST['w2a_nonce']) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['w2a_nonce'])), 'w2a_generate_action')
        ) {
            self::redirect_with_error('Security check fail hua, dobara try karen.');
        }

        $websiteUrl = isset($_POST['website_url']) ? esc_url_raw(wp_unslash($_POST['website_url'])) : '';
        $appName = isset($_POST['app_name']) ? sanitize_text_field(wp_unslash($_POST['app_name'])) : 'My WebApp';
        $packageName = isset($_POST['package_name']) ? sanitize_text_field(wp_unslash($_POST['package_name'])) : '';

        $result = W2A_Generator::generate_and_stream($websiteUrl, $appName, $packageName);

        // generate_and_stream() only returns if something went wrong
        // (on success it streams the zip and calls exit() itself)
        if (is_wp_error($result)) {
            self::redirect_with_error($result->get_error_message());
        }
    }

    private static function redirect_with_error($message) {
        $referer = wp_get_referer() ? wp_get_referer() : home_url();
        $redirect = add_query_arg('w2a_error', rawurlencode($message), $referer);
        wp_safe_redirect($redirect);
        exit;
    }
}
